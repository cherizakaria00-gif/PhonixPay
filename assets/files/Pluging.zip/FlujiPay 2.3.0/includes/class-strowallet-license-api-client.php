<?php
if (!defined('ABSPATH')) {
    exit;
}

class Strowallet_License_API_Client
{
    const DEFAULT_BASE_URL = 'https://flujipay.com/api/licenses';

    /**
     * Validate a license against FlujiPay.
     *
     * @param array $payload License payload.
     *
     * @return array
     */
    public function validate_license($payload)
    {
        return $this->request('validate', $payload);
    }

    /**
     * Deactivate a license against FlujiPay.
     *
     * @param array $payload License payload.
     *
     * @return array
     */
    public function deactivate_license($payload)
    {
        return $this->request('deactivate', $payload);
    }

    /**
     * Fetch license details from FlujiPay.
     *
     * @param array $payload License payload.
     *
     * @return array
     */
    public function fetch_license_details($payload)
    {
        return $this->request('details', $payload);
    }

    /**
     * Execute a JSON API request.
     *
     * @param string $endpoint Endpoint name.
     * @param array  $payload  Request body.
     *
     * @return array
     */
    protected function request($endpoint, $payload)
    {
        $url = trailingslashit($this->get_base_url()) . ltrim($endpoint, '/');

        $response = wp_remote_post(
            esc_url_raw($url),
            array(
                'timeout' => 15,
                'headers' => array(
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',
                ),
                'body'    => wp_json_encode($payload),
            )
        );

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'code'    => 'request_error',
                'message' => $response->get_error_message(),
                'data'    => array(),
            );
        }

        $status_code = (int) wp_remote_retrieve_response_code($response);
        $body        = wp_remote_retrieve_body($response);
        $decoded     = json_decode($body, true);

        if (JSON_ERROR_NONE !== json_last_error()) {
            return array(
                'success' => false,
                'code'    => 'invalid_json',
                'message' => __('License validation failed because FlujiPay returned an unreadable response.', 'strowallet-woo-payment-gateway'),
                'data'    => array(
                    'status_code' => $status_code,
                    'raw_body'    => $body,
                ),
            );
        }

        if (!is_array($decoded)) {
            return array(
                'success' => false,
                'code'    => 'invalid_response',
                'message' => __('License validation failed because FlujiPay returned an invalid response.', 'strowallet-woo-payment-gateway'),
                'data'    => array(
                    'status_code' => $status_code,
                    'raw_body'    => $body,
                ),
            );
        }

        return $this->normalize_response($decoded, $status_code);
    }

    /**
     * Normalize FlujiPay responses into a stable shape.
     *
     * @param array $response    API response body.
     * @param int   $status_code HTTP status code.
     *
     * @return array
     */
    protected function normalize_response($response, $status_code)
    {
        $data          = isset($response['data']) && is_array($response['data']) ? $response['data'] : array();
        $status        = isset($response['status']) ? strtolower((string) $response['status']) : '';
        $success_field = isset($response['success']) ? (bool) $response['success'] : null;
        $valid_field   = isset($response['valid']) ? (bool) $response['valid'] : null;
        $code          = isset($response['code']) ? sanitize_key($response['code']) : '';
        $message       = isset($response['message']) ? sanitize_text_field($response['message']) : '';

        if ('' === $message) {
            if ($status_code >= 500) {
                $message = __('License validation failed because the FlujiPay server returned an error.', 'strowallet-woo-payment-gateway');
            } elseif ($status_code >= 400) {
                $message = __('License validation failed. Please verify the email, site URL, and license key.', 'strowallet-woo-payment-gateway');
            } else {
                $message = __('License validation failed. Please try again.', 'strowallet-woo-payment-gateway');
            }
        }

        $is_valid = false;

        if (null !== $valid_field) {
            $is_valid = $valid_field;
        } elseif (null !== $success_field) {
            $is_valid = $success_field;
        } elseif (in_array($status, array('valid', 'active', 'success', 'ok'), true)) {
            $is_valid = true;
        }

        if ($status_code < 200 || $status_code >= 300) {
            $is_valid = false;
        }

        return array(
            'success' => $is_valid,
            'code'    => $code ? $code : ($is_valid ? 'valid' : 'validation_failed'),
            'message' => $message,
            'data'    => array(
                'status_code'    => $status_code,
                'status'         => $status,
                'email'          => isset($data['email']) ? sanitize_email($data['email']) : '',
                'site_url'       => isset($data['site_url']) ? esc_url_raw($data['site_url']) : '',
                'domain'         => isset($data['domain']) ? sanitize_text_field($data['domain']) : '',
                'license_status' => isset($data['license_status']) ? sanitize_key($data['license_status']) : $status,
                'raw'            => $response,
            ),
        );
    }

    /**
     * Get the FlujiPay license API base URL.
     *
     * @return string
     */
    protected function get_base_url()
    {
        $base_url = defined('STROWALLET_LICENSE_API_BASE_URL') ? STROWALLET_LICENSE_API_BASE_URL : self::DEFAULT_BASE_URL;

        return (string) apply_filters('strowallet_license_api_base_url', $base_url);
    }
}
