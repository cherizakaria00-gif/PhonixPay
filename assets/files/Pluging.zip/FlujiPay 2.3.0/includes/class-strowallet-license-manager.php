<?php
if (!defined('ABSPATH')) {
    exit;
}

class Strowallet_License_Manager
{
    const OPTION_KEY = 'strowallet_license_data';
    const NOTICE_KEY = 'strowallet_license_notice';
    const CRON_HOOK = 'strowallet_license_revalidate_event';
    const REVALIDATE_INTERVAL = DAY_IN_SECONDS;

    /**
     * @var self|null
     */
    protected static $instance = null;

    /**
     * @var Strowallet_License_API_Client
     */
    protected $api_client;

    /**
     * @return self
     */
    public static function instance()
    {
        if (null === static::$instance) {
            static::$instance = new static(new Strowallet_License_API_Client());
        }

        return static::$instance;
    }

    /**
     * @param Strowallet_License_API_Client $api_client API client.
     */
    public function __construct(Strowallet_License_API_Client $api_client)
    {
        $this->api_client = $api_client;
    }

    /**
     * Register recurring revalidation.
     *
     * @return void
     */
    public static function maybe_schedule_revalidation()
    {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK);
        }
    }

    /**
     * Clear scheduled revalidation.
     *
     * @return void
     */
    public static function clear_scheduled_revalidation()
    {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);

        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    /**
     * Cron callback.
     *
     * @return void
     */
    public static function handle_scheduled_revalidation()
    {
        self::instance()->maybe_revalidate_stored_license('scheduled');
    }

    /**
     * Get default license data.
     *
     * @return array
     */
    public function get_default_data()
    {
        $site_url = home_url('/');

        return array(
            'email'                   => '',
            'site_url'                => esc_url_raw($site_url),
            'site_domain'             => $this->normalize_domain($site_url),
            'license_key'             => '',
            'activation_status'       => 'inactive',
            'last_validation_date'    => '',
            'last_validation_message' => '',
            'last_validation_code'    => '',
        );
    }

    /**
     * Get current stored license data.
     *
     * @return array
     */
    public function get_license_data()
    {
        $stored = get_option(self::OPTION_KEY, array());

        return wp_parse_args(is_array($stored) ? $stored : array(), $this->get_default_data());
    }

    /**
     * Update stored license data.
     *
     * @param array $data License data.
     *
     * @return array
     */
    public function update_license_data($data)
    {
        $current = $this->get_license_data();
        $merged  = wp_parse_args($data, $current);
        $clean   = array(
            'email'                   => sanitize_email($merged['email']),
            'site_url'                => esc_url_raw($merged['site_url']),
            'site_domain'             => $this->normalize_domain($merged['site_url']),
            'license_key'             => sanitize_text_field($merged['license_key']),
            'activation_status'       => sanitize_key($merged['activation_status']),
            'last_validation_date'    => sanitize_text_field($merged['last_validation_date']),
            'last_validation_message' => sanitize_text_field($merged['last_validation_message']),
            'last_validation_code'    => sanitize_key($merged['last_validation_code']),
        );

        update_option(self::OPTION_KEY, $clean, false);

        return $clean;
    }

    /**
     * Save license fields from the settings form without activating.
     *
     * @param array $raw_license_data Raw submitted data.
     *
     * @return array
     */
    public function save_license_fields($raw_license_data)
    {
        $current_site_url = home_url('/');

        return $this->update_license_data(
            array(
                'email'       => isset($raw_license_data['email']) ? $raw_license_data['email'] : '',
                'site_url'    => $current_site_url,
                'license_key' => isset($raw_license_data['license_key']) ? $raw_license_data['license_key'] : '',
            )
        );
    }

    /**
     * Check if the current site has a valid active license.
     *
     * @return bool
     */
    public function is_license_active()
    {
        $license_data = $this->get_license_data();

        if ('active' !== $license_data['activation_status']) {
            return false;
        }

        return $license_data['site_domain'] === $this->normalize_domain(home_url('/'));
    }

    /**
     * Normalize a URL or domain into a bare domain.
     *
     * @param string $value URL or domain.
     *
     * @return string
     */
    public function normalize_domain($value)
    {
        $value = trim((string) $value);

        if ('' === $value) {
            return '';
        }

        if (0 !== strpos($value, 'http://') && 0 !== strpos($value, 'https://')) {
            $value = 'https://' . ltrim($value, '/');
        }

        $host = wp_parse_url($value, PHP_URL_HOST);

        if (!$host) {
            $host = $value;
        }

        $host = strtolower((string) $host);
        $host = preg_replace('/:\d+$/', '', $host);
        $host = preg_replace('/^www\./', '', $host);

        return sanitize_text_field($host);
    }

    /**
     * Activate the stored license.
     *
     * @param array  $license_data Stored license data.
     * @param string $context      Validation context.
     *
     * @return array
     */
    public function activate_license($license_data, $context = 'manual')
    {
        $site_url = home_url('/');
        $payload  = array(
            'email'       => sanitize_email($license_data['email']),
            'site_url'    => esc_url_raw($site_url),
            'domain'      => $this->normalize_domain($site_url),
            'license_key' => sanitize_text_field($license_data['license_key']),
            'plugin'      => 'flujipay-woocommerce',
            'version'     => defined('WC_STROWALLET_VERSION') ? WC_STROWALLET_VERSION : '',
            'context'     => sanitize_key($context),
        );

        if (empty($payload['email']) || empty($payload['license_key'])) {
            $message = __('Merchant email and license key are required before activation.', 'strowallet-woo-payment-gateway');

            return $this->store_validation_failure('invalid_request', $message, $license_data, $site_url);
        }

        $response = $this->api_client->validate_license($payload);

        if (!$response['success']) {
            return $this->store_validation_failure(
                $response['code'],
                $this->map_error_message($response, $payload),
                $license_data,
                $site_url
            );
        }

        $response_email  = !empty($response['data']['email']) ? $response['data']['email'] : $payload['email'];
        $response_domain = !empty($response['data']['domain']) ? $this->normalize_domain($response['data']['domain']) : '';

        if ($response_email && $response_email !== $payload['email']) {
            return $this->store_validation_failure(
                'email_mismatch',
                __('Email mismatch. The FlujiPay license was issued for a different merchant email.', 'strowallet-woo-payment-gateway'),
                $license_data,
                $site_url
            );
        }

        if ($response_domain && $response_domain !== $payload['domain']) {
            return $this->store_validation_failure(
                'domain_mismatch',
                __('Domain mismatch. This FlujiPay license does not match the current website domain.', 'strowallet-woo-payment-gateway'),
                $license_data,
                $site_url
            );
        }

        $updated = $this->update_license_data(
            array(
                'email'                   => $payload['email'],
                'site_url'                => $site_url,
                'license_key'             => $payload['license_key'],
                'activation_status'       => 'active',
                'last_validation_date'    => current_time('mysql'),
                'last_validation_message' => __('License activated successfully.', 'strowallet-woo-payment-gateway'),
                'last_validation_code'    => 'valid',
            )
        );

        $this->queue_notice(__('License activated successfully.', 'strowallet-woo-payment-gateway'), 'success');

        return array(
            'success' => true,
            'message' => $updated['last_validation_message'],
            'data'    => $updated,
        );
    }

    /**
     * Revalidate stored license if enough time has passed or if forced.
     *
     * @param string $context Validation context.
     * @param bool   $force   Force revalidation.
     *
     * @return array
     */
    public function maybe_revalidate_stored_license($context = 'scheduled', $force = false)
    {
        $license_data = $this->get_license_data();

        if (empty($license_data['email']) || empty($license_data['license_key'])) {
            return array(
                'success' => false,
                'message' => __('License data is incomplete.', 'strowallet-woo-payment-gateway'),
                'data'    => $license_data,
            );
        }

        if (!$force && !empty($license_data['last_validation_date'])) {
            $last_validation = strtotime($license_data['last_validation_date']);

            if ($last_validation && (time() - $last_validation) < self::REVALIDATE_INTERVAL) {
                return array(
                    'success' => 'active' === $license_data['activation_status'],
                    'message' => __('License revalidation skipped because the last validation is still fresh.', 'strowallet-woo-payment-gateway'),
                    'data'    => $license_data,
                );
            }
        }

        return $this->activate_license($license_data, $context);
    }

    /**
     * Deactivate the stored license locally and remotely.
     *
     * @param bool $remote Whether to notify FlujiPay.
     *
     * @return array
     */
    public function deactivate_license($remote = true)
    {
        $license_data = $this->get_license_data();
        $site_url     = home_url('/');

        if ($remote && !empty($license_data['license_key'])) {
            $this->api_client->deactivate_license(
                array(
                    'email'       => $license_data['email'],
                    'site_url'    => esc_url_raw($site_url),
                    'domain'      => $this->normalize_domain($site_url),
                    'license_key' => $license_data['license_key'],
                    'plugin'      => 'flujipay-woocommerce',
                )
            );
        }

        $cleared = $this->update_license_data(
            array(
                'email'                   => '',
                'site_url'                => esc_url_raw($site_url),
                'license_key'             => '',
                'activation_status'       => 'inactive',
                'last_validation_date'    => current_time('mysql'),
                'last_validation_message' => __('License deactivated locally.', 'strowallet-woo-payment-gateway'),
                'last_validation_code'    => 'deactivated',
            )
        );

        $this->queue_notice(__('License deactivated successfully.', 'strowallet-woo-payment-gateway'), 'success');

        return array(
            'success' => true,
            'message' => $cleared['last_validation_message'],
            'data'    => $cleared,
        );
    }

    /**
     * Show queued admin notices.
     *
     * @return void
     */
    public function output_admin_notice()
    {
        $notice = get_transient(self::NOTICE_KEY);

        if (!is_array($notice) || empty($notice['message'])) {
            return;
        }

        delete_transient(self::NOTICE_KEY);

        $class = 'notice notice-info';

        if ('error' === $notice['type']) {
            $class = 'notice notice-error';
        } elseif ('success' === $notice['type']) {
            $class = 'notice notice-success';
        } elseif ('warning' === $notice['type']) {
            $class = 'notice notice-warning';
        }

        echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($notice['message']) . '</p></div>';
    }

    /**
     * Queue an admin notice for the next page load.
     *
     * @param string $message Notice text.
     * @param string $type    Notice type.
     *
     * @return void
     */
    public function queue_notice($message, $type = 'info')
    {
        set_transient(
            self::NOTICE_KEY,
            array(
                'message' => sanitize_text_field($message),
                'type'    => sanitize_key($type),
            ),
            MINUTE_IN_SECONDS
        );
    }

    /**
     * Build a settings-friendly status label.
     *
     * @return string
     */
    public function get_status_label()
    {
        $license_data = $this->get_license_data();
        $status       = $license_data['activation_status'];

        if ('active' === $status && $this->is_license_active()) {
            return __('Active', 'strowallet-woo-payment-gateway');
        }

        $labels = array(
            'inactive'        => __('Inactive', 'strowallet-woo-payment-gateway'),
            'invalid'         => __('Invalid', 'strowallet-woo-payment-gateway'),
            'domain_mismatch' => __('Domain mismatch', 'strowallet-woo-payment-gateway'),
            'email_mismatch'  => __('Email mismatch', 'strowallet-woo-payment-gateway'),
            'revoked'         => __('Revoked', 'strowallet-woo-payment-gateway'),
            'deactivated'     => __('Deactivated', 'strowallet-woo-payment-gateway'),
            'request_error'   => __('Validation error', 'strowallet-woo-payment-gateway'),
        );

        return isset($labels[$status]) ? $labels[$status] : ucfirst(str_replace('_', ' ', $status));
    }

    /**
     * Map API failures into merchant-facing messages.
     *
     * @param array $response Validation response.
     * @param array $payload  Validation payload.
     *
     * @return string
     */
    protected function map_error_message($response, $payload)
    {
        $code = isset($response['code']) ? $response['code'] : '';

        if ('domain_mismatch' === $code) {
            return __('Domain mismatch. This FlujiPay license does not match the current website domain.', 'strowallet-woo-payment-gateway');
        }

        if ('email_mismatch' === $code) {
            return __('Email mismatch. The FlujiPay license was issued for a different merchant email.', 'strowallet-woo-payment-gateway');
        }

        if ('revoked' === $code || 'license_revoked' === $code) {
            return __('License revoked. Please generate a new FlujiPay license from your merchant dashboard.', 'strowallet-woo-payment-gateway');
        }

        if ('invalid' === $code || 'invalid_license' === $code || 'validation_failed' === $code) {
            return __('Invalid license key. Please verify the FlujiPay merchant email and license key.', 'strowallet-woo-payment-gateway');
        }

        if ('request_error' === $code || 'invalid_json' === $code || 'invalid_response' === $code) {
            return __('License validation failed. FlujiPay could not be reached or returned an invalid response.', 'strowallet-woo-payment-gateway');
        }

        if (!empty($response['message'])) {
            return $response['message'];
        }

        return sprintf(
            __('License validation failed for %s.', 'strowallet-woo-payment-gateway'),
            esc_html($payload['domain'])
        );
    }

    /**
     * Persist a validation failure in local storage and admin notices.
     *
     * @param string $code         Failure code.
     * @param string $message      Failure message.
     * @param array  $license_data Current license data.
     * @param string $site_url     Current site URL.
     *
     * @return array
     */
    protected function store_validation_failure($code, $message, $license_data, $site_url)
    {
        $status = sanitize_key($code);

        if (!in_array($status, array('domain_mismatch', 'email_mismatch', 'revoked', 'request_error'), true)) {
            $status = 'invalid';
        }

        $updated = $this->update_license_data(
            array(
                'email'                   => isset($license_data['email']) ? $license_data['email'] : '',
                'site_url'                => esc_url_raw($site_url),
                'license_key'             => isset($license_data['license_key']) ? $license_data['license_key'] : '',
                'activation_status'       => $status,
                'last_validation_date'    => current_time('mysql'),
                'last_validation_message' => $message,
                'last_validation_code'    => sanitize_key($code),
            )
        );

        $this->queue_notice($message, 'error');

        return array(
            'success' => false,
            'message' => $message,
            'data'    => $updated,
        );
    }
}
