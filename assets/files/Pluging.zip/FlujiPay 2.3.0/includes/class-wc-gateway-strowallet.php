<?php
if (class_exists("WC_Payment_Gateway")) {
    class WC_strowallet_Payment_Gateway extends WC_Payment_Gateway_CC
    {
        /**
         * API strowallet key
         *
         * @var string
         */
        public $public_key;

        /**
         * API secret key
         *
         * @var string
         */
        public $secret_key;

        /**
         * Test mode public key
         *
         * @var string
         */
        public $test_public_key;

        /**
         * Test mode secret key
         *
         * @var string
         */
        public $test_secret_key;
        /**
         * Redirect URL after successful payment
         *
         * @var string
         */
        public $redirect_url;
        /**
         * strowallet APIURL.
         *
         * @var string
         */
        public $apiURL;
        /**
         * Enabled currencies for this gateway.
         *
         * @var array
         */
        public $supported_currencies = array();

        /**
         * License manager.
         *
         * @var Strowallet_License_Manager
         */
        protected $license_manager;


        /**
         * Constructor
         */
        public function __construct()
        {
            $this->id = "strowallet";
            // $this->icon = apply_filters("woocommerce_strowallet_icon", plugins_url( 'assets/images/strowallet.png', WC_STROWALLET_MAIN_FILE ));
            $this->has_fields = true;
            $this->method_title = __("FlujiPay Payment Gateway", "strowallet-woo-payment-gateway");
            $this->method_description = sprintf(__('FlujiPay Provide Merchants Plugin and Services Needed To Accept Online Payments <a href="%1$s" target="_blank">Get your API keys</a>.', 'strowallet-woo-payment-gateway'), 'https://flujipay.com');
            $this->supports = array(
                'products',
                'tokenization',
                'subscriptions',
                'subscription_cancellation',
                'subscription_suspension',
                'subscription_reactivation',
                'subscription_amount_changes',
                'subscription_date_changes',
                'subscription_payment_method_change',
                'subscription_payment_method_change_customer',
                'subscription_payment_method_change_admin',
                'multiple_subscriptions',
            );
            // Load the form fields
            $this->init_form_fields();
            // Load the settings
            $this->init_settings();
            //Load 
            $this->title       = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->enabled     = $this->get_option('enabled');

            $this->testmode    = 'yes' === $this->get_option('testmode');

            $this->apiURL = $this->testmode
                ? "https://flujipay.com/test/payment/initiate"
                : "https://flujipay.com/payment/initiate";

            $this->test_public_key = $this->get_option('test_public_key');
            $this->test_secret_key = $this->get_option('test_secret_key');

            $live_public_key = $this->get_option('public_key');
            $live_secret_key = $this->get_option('secret_key');

            if ($this->testmode) {
                $this->public_key = $this->test_public_key;
                $this->secret_key = $this->test_secret_key;
            } else {
                $this->public_key = $live_public_key;
                $this->secret_key = $live_secret_key;
            }
            $this->redirect_url         = $this->get_option('redirect_url');
            $this->supported_currencies = $this->get_enabled_supported_currencies();
            $this->license_manager      = Strowallet_License_Manager::instance();
            // Hooks
            add_action('wp_enqueue_scripts', array($this, 'payment_scripts'));
            add_action('woocommerce_available_payment_gateways', array($this, 'add_gateway_to_checkout'));
            add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
            add_action('admin_notices', array($this, 'admin_notices'));
            add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
            add_action('woocommerce_api_wc_strowallet_payment_gateway', array($this, 'strowallet_verify_payment'));
            add_action(
                'woocommerce_update_options_payment_gateways_' . $this->id,
                array(
                    $this,
                    'process_admin_options',
                )
            );
            // Check if the gateway can be used.
            if (!$this->is_valid_for_use()) {
                $this->enabled = false;
            }
        }

        public function init_form_fields()
        {
            $form_fields = apply_filters(
                "woo_ade_strowallet_fields",
                array(
                    "enabled" => array(
                        "title" => __("Enable/Disable", "strowallet-woo-payment-gateway"),
                        "type" => "checkbox",
                        "label" => __("Enable or Disable FlujiPay Payment", "strowallet-woo-payment-gateway"),
                        "default" => "no"
                    ),
                    'testmode'                   => array(
                        'title'       => __('Mode', 'strowallet-woo-payment-gateway'),
                        'type'        => 'strowallet_mode_switch',
                        'default'     => 'no',
                        'description' => __('Switch between Test Mode and Live Mode.', 'strowallet-woo-payment-gateway'),
                    ),
                    'section_test'               => array(
                        'title'       => __('Test Mode Settings', 'strowallet-woo-payment-gateway'),
                        'type'        => 'title',
                        'description' => __('Used only when Test Mode is enabled.', 'strowallet-woo-payment-gateway'),
                        'class'       => 'wc-strowallet-test-field',
                    ),
                    'test_public_key'            => array(
                        'title'       => __('Test Public Key', 'strowallet-woo-payment-gateway'),
                        'type'        => 'text',
                        'description' => __('Enter your Test Public Key here.', 'strowallet-woo-payment-gateway'),
                        'default'     => '',
                        'class'       => 'wc-strowallet-test-field',
                    ),
                    'test_secret_key'            => array(
                        'title'       => __('Test Secret Key', 'strowallet-woo-payment-gateway'),
                        'type'        => 'text',
                        'description' => __('Enter your Test Secret Key here.', 'strowallet-woo-payment-gateway'),
                        'default'     => '',
                        'class'       => 'wc-strowallet-test-field',
                    ),
                    'section_live'               => array(
                        'title'       => __('Live Mode Settings', 'strowallet-woo-payment-gateway'),
                        'type'        => 'title',
                        'description' => __('Used only when Test Mode is disabled.', 'strowallet-woo-payment-gateway'),
                        'class'       => 'wc-strowallet-live-field',
                    ),
                    'public_key'                 => array(
                        'title'       => __('Live Public Key', 'strowallet-woo-payment-gateway'),
                        'type'        => 'text',
                        'description' => __('Enter your Live Public Key here.', 'strowallet-woo-payment-gateway'),
                        'default'     => '',
                        'class'       => 'wc-strowallet-live-field',
                    ),
                    'secret_key'                 => array(
                        'title'       => __('Live Secret Key', 'strowallet-woo-payment-gateway'),
                        'type'        => 'text',
                        'description' => __('Enter your Live Secret Key here.', 'strowallet-woo-payment-gateway'),
                        'default'     => '',
                        'class'       => 'wc-strowallet-live-field',
                    ),
                    "title" => array(
                        "title" => __("Title", "strowallet-woo-payment-gateway"),
                        "type" => "text",
                        "description" => __("This controls the payment method title which the user sees during checkout.", "strowallet-woo-payment-gateway"),
                        "default" => __("FlujiPay Payment", "strowallet-woo-payment-gateway"),
                        "desc_tip" => true
                    ),
                    "description" => array(
                        "title" => __("Payment Description", "strowallet-woo-payment-gateway"),
                        "type" => "textarea",
                        "description" => __("Add a new description", "strowallet-woo-payment-gateway"),
                        "default" => __("Accept Payments Seamlessly via Bank Transfer.", "strowallet-woo-payment-gateway"),
                        "desc_tip" => true
                    ),
                    'supported_currencies' => array(
                        'title'       => __('Supported Currencies', 'strowallet-woo-payment-gateway'),
                        'type'        => 'multiselect',
                        'description' => __('Select the currencies customers can pay with FlujiPay.', 'strowallet-woo-payment-gateway'),
                        'default'     => $this->get_default_supported_currencies(),
                        'desc_tip'    => true,
                        'class'       => 'wc-enhanced-select',
                        'css'         => 'width: 300px;',
                        'options'     => $this->get_supported_currency_options(),
                    ),
                    "instructions" => array(
                        "title" => __("Instructions", "strowallet-woo-payment-gateway"),
                        "type" => "textarea",
                        "description" => __("Instructions that will be added to the thank you page."),
                        "default" => __("", "strowallet-woo-payment-gateway"),
                        "desc_tip" => true
                    ),
                    'license_section'            => array(
                        'title'       => __('License Settings', 'strowallet-woo-payment-gateway'),
                        'type'        => 'title',
                        'description' => __('Activate the FlujiPay license generated from your merchant dashboard. Payments remain blocked until the license is valid for this domain.', 'strowallet-woo-payment-gateway'),
                    ),
                    'license_email'              => array(
                        'title'       => __('Merchant Email', 'strowallet-woo-payment-gateway'),
                        'type'        => 'strowallet_license_text',
                        'field_type'  => 'email',
                        'license_key' => 'email',
                        'description' => __('Use the same email address used when generating the FlujiPay license.', 'strowallet-woo-payment-gateway'),
                    ),
                    'license_site_url'           => array(
                        'title'       => __('Website URL', 'strowallet-woo-payment-gateway'),
                        'type'        => 'strowallet_license_text',
                        'field_type'  => 'url',
                        'license_key' => 'site_url',
                        'description' => __('The current WordPress site URL is normalized before validation. Example: https://www.example.com becomes example.com.', 'strowallet-woo-payment-gateway'),
                    ),
                    'license_key'                => array(
                        'title'       => __('License Key', 'strowallet-woo-payment-gateway'),
                        'type'        => 'strowallet_license_text',
                        'field_type'  => 'text',
                        'license_key' => 'license_key',
                        'description' => __('Paste the license key generated in the FlujiPay merchant dashboard.', 'strowallet-woo-payment-gateway'),
                    ),
                    'license_status'             => array(
                        'title' => __('License Status', 'strowallet-woo-payment-gateway'),
                        'type'  => 'strowallet_license_status',
                    ),
                    'license_last_validation'    => array(
                        'title' => __('Last Validation Date', 'strowallet-woo-payment-gateway'),
                        'type'  => 'strowallet_license_last_validation',
                    ),
                    'license_actions'            => array(
                        'title' => __('License Actions', 'strowallet-woo-payment-gateway'),
                        'type'  => 'strowallet_license_actions',
                    ),
                    'redirect_url'               => array(
                        'title'       => __('Redirect After Payment', 'strowallet-woo-payment-gateway'),
                        'type'        => 'text',
                        'description' => __('Optional: full URL to redirect customers after successful payment. Leave blank to use the default WooCommerce order received page.', 'strowallet-woo-payment-gateway'),
                        'placeholder' => 'https://example.com/thank-you',
                        'default'     => '',
                        'desc_tip'    => true,
                    ),
                )
            );

            $this->form_fields = $form_fields;
        }

        /**
         * Supported currency options.
         *
         * @return array
         */
        protected function get_supported_currency_options()
        {
            return apply_filters(
                'woocommerce_strowallet_supported_currency_options',
                array(
                    'USD' => __('US Dollar (USD)', 'strowallet-woo-payment-gateway'),
                    'EUR' => __('Euro (EUR)', 'strowallet-woo-payment-gateway'),
                    'CAD' => __('Canadian Dollar (CAD)', 'strowallet-woo-payment-gateway'),
                    'XOF' => __('West African CFA franc (XOF)', 'strowallet-woo-payment-gateway'),
                    'XAF' => __('Central African CFA franc (XAF)', 'strowallet-woo-payment-gateway'),
                )
            );
        }

        /**
         * Default supported currencies.
         *
         * @return array
         */
        protected function get_default_supported_currencies()
        {
            return array('USD', 'EUR', 'CAD', 'XOF', 'XAF');
        }

        /**
         * Get gateway enabled currencies from settings.
         *
         * @return array
         */
        protected function get_enabled_supported_currencies()
        {
            $available_currencies = array_keys($this->get_supported_currency_options());
            $saved_currencies     = $this->get_option('supported_currencies', $this->get_default_supported_currencies());

            if (!is_array($saved_currencies)) {
                $saved_currencies = array($saved_currencies);
            }

            $saved_currencies = array_unique(array_map('strtoupper', array_map('sanitize_text_field', $saved_currencies)));
            $currencies       = array_values(array_intersect($available_currencies, $saved_currencies));

            if (empty($currencies)) {
                $currencies = $this->get_default_supported_currencies();
            }

            return apply_filters('woocommerce_strowallet_supported_currencies', $currencies);
        }

        /**
         * Check if a currency is supported by this gateway.
         *
         * @param string $currency Currency code.
         *
         * @return bool
         */
        protected function is_currency_supported($currency)
        {
            return in_array(strtoupper((string) $currency), $this->supported_currencies, true);
        }

        /**
         * Custom mode switch field (Live/Test).
         */
        public function generate_strowallet_mode_switch_html($key, $data)
        {
            $defaults = array(
                'title'       => '',
                'description' => '',
                'class'       => '',
            );

            $data = wp_parse_args($data, $defaults);

            $field_key  = $this->get_field_key($key);
            $is_live    = ('yes' !== $this->get_option($key));
            $mode_title = $data['title'];
            $mode_desc  = $data['description'];

            ob_start();
            ?>
            <tr valign="top" class="wc-strowallet-mode-row <?php echo esc_attr($data['class']); ?>">
                <th scope="row" class="titledesc">
                    <label for="<?php echo esc_attr($field_key); ?>"><?php echo esc_html($mode_title); ?></label>
                </th>
                <td class="forminp">
                    <div class="wc-strowallet-mode-toggle">
                        <span class="wc-strowallet-mode-text wc-strowallet-mode-text--test"><?php esc_html_e('Test Mode', 'strowallet-woo-payment-gateway'); ?></span>
                        <label class="wc-strowallet-switch">
                            <input type="hidden" name="<?php echo esc_attr($field_key); ?>" value="yes" />
                            <input type="checkbox" id="<?php echo esc_attr($field_key); ?>" name="<?php echo esc_attr($field_key); ?>" value="no" <?php checked($is_live); ?> />
                            <span class="wc-strowallet-slider"></span>
                        </label>
                        <span class="wc-strowallet-mode-text wc-strowallet-mode-text--live"><?php esc_html_e('Live Mode', 'strowallet-woo-payment-gateway'); ?></span>
                    </div>
                    <?php if (!empty($mode_desc)) : ?>
                        <p class="description"><?php echo wp_kses_post($mode_desc); ?></p>
                    <?php endif; ?>
                </td>
            </tr>
            <?php
            return ob_get_clean();
        }

        /**
         * Render license text inputs stored in a dedicated option.
         *
         * @param string $key  Field key.
         * @param array  $data Field config.
         *
         * @return string
         */
        public function generate_strowallet_license_text_html($key, $data)
        {
            $license_key = isset($data['license_key']) ? $data['license_key'] : '';
            $field_type  = isset($data['field_type']) ? $data['field_type'] : 'text';
            $value       = $this->get_license_field_value($license_key);
            $readonly    = ('site_url' === $license_key) ? 'readonly="readonly"' : '';

            ob_start();
            ?>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="strowallet-license-<?php echo esc_attr($license_key); ?>"><?php echo esc_html($data['title']); ?></label>
                </th>
                <td class="forminp">
                    <input
                        id="strowallet-license-<?php echo esc_attr($license_key); ?>"
                        name="strowallet_license[<?php echo esc_attr($license_key); ?>]"
                        type="<?php echo esc_attr($field_type); ?>"
                        class="regular-text"
                        value="<?php echo esc_attr($value); ?>"
                        autocomplete="off"
                        <?php echo $readonly; ?>
                    />
                    <?php if (!empty($data['description'])) : ?>
                        <p class="description"><?php echo esc_html($data['description']); ?></p>
                    <?php endif; ?>
                </td>
            </tr>
            <?php

            return ob_get_clean();
        }

        /**
         * Render the license status row.
         *
         * @param string $key  Field key.
         * @param array  $data Field config.
         *
         * @return string
         */
        public function generate_strowallet_license_status_html($key, $data)
        {
            $license_data = $this->license_manager->get_license_data();

            ob_start();
            ?>
            <tr valign="top">
                <th scope="row" class="titledesc"><?php echo esc_html($data['title']); ?></th>
                <td class="forminp">
                    <strong><?php echo esc_html($this->license_manager->get_status_label()); ?></strong>
                    <?php if (!empty($license_data['last_validation_message'])) : ?>
                        <p class="description"><?php echo esc_html($license_data['last_validation_message']); ?></p>
                    <?php endif; ?>
                </td>
            </tr>
            <?php

            return ob_get_clean();
        }

        /**
         * Render the last validation timestamp row.
         *
         * @param string $key  Field key.
         * @param array  $data Field config.
         *
         * @return string
         */
        public function generate_strowallet_license_last_validation_html($key, $data)
        {
            $license_data = $this->license_manager->get_license_data();
            $date         = $license_data['last_validation_date'];

            ob_start();
            ?>
            <tr valign="top">
                <th scope="row" class="titledesc"><?php echo esc_html($data['title']); ?></th>
                <td class="forminp">
                    <span><?php echo $date ? esc_html($date) : esc_html__('Never', 'strowallet-woo-payment-gateway'); ?></span>
                </td>
            </tr>
            <?php

            return ob_get_clean();
        }

        /**
         * Render the license action buttons.
         *
         * @param string $key  Field key.
         * @param array  $data Field config.
         *
         * @return string
         */
        public function generate_strowallet_license_actions_html($key, $data)
        {
            ob_start();
            ?>
            <tr valign="top">
                <th scope="row" class="titledesc"><?php echo esc_html($data['title']); ?></th>
                <td class="forminp">
                    <?php wp_nonce_field('strowallet_license_action', 'strowallet_license_nonce'); ?>
                    <button type="submit" class="button button-primary" name="strowallet_license_action" value="activate"><?php esc_html_e('Activate License', 'strowallet-woo-payment-gateway'); ?></button>
                    <button type="submit" class="button" name="strowallet_license_action" value="revalidate"><?php esc_html_e('Revalidate License', 'strowallet-woo-payment-gateway'); ?></button>
                    <button type="submit" class="button" name="strowallet_license_action" value="deactivate"><?php esc_html_e('Deactivate License', 'strowallet-woo-payment-gateway'); ?></button>
                    <p class="description"><?php esc_html_e('Activation always validates against the current WordPress site URL and normalized domain.', 'strowallet-woo-payment-gateway'); ?></p>
                </td>
            </tr>
            <?php

            return ob_get_clean();
        }

        /**
         * Read a license field from dedicated storage.
         *
         * @param string $license_key License data key.
         *
         * @return string
         */
        protected function get_license_field_value($license_key)
        {
            $license_data = $this->license_manager->get_license_data();

            if ('site_url' === $license_key && empty($license_data['site_url'])) {
                return esc_url_raw(home_url('/'));
            }

            return isset($license_data[$license_key]) ? (string) $license_data[$license_key] : '';
        }

        /**
         * Persist gateway settings and handle license actions.
         *
         * @return bool
         */
        public function process_admin_options()
        {
            $result = parent::process_admin_options();

            if (!current_user_can('manage_woocommerce')) {
                return $result;
            }

            $posted_license_data = array();

            if (isset($_POST['strowallet_license']) && is_array($_POST['strowallet_license'])) {
                $posted_license_data = wp_unslash($_POST['strowallet_license']);
            }

            $license_data = $this->license_manager->save_license_fields($posted_license_data);
            $action       = isset($_POST['strowallet_license_action']) ? sanitize_key(wp_unslash($_POST['strowallet_license_action'])) : '';

            if ($action && (!isset($_POST['strowallet_license_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['strowallet_license_nonce'])), 'strowallet_license_action'))) {
                $this->license_manager->queue_notice(__('License validation failed because the security nonce was invalid.', 'strowallet-woo-payment-gateway'), 'error');

                return $result;
            }

            if ('activate' === $action) {
                $this->license_manager->activate_license($license_data, 'manual_activation');
            } elseif ('revalidate' === $action) {
                $this->license_manager->activate_license($license_data, 'manual_revalidation');
            } elseif ('deactivate' === $action) {
                $this->license_manager->deactivate_license(true);
                $this->force_gateway_disabled();
            } else {
                $this->maybe_revalidate_license_after_settings_save($license_data);
            }

            if (!$this->license_manager->is_license_active()) {
                $this->force_gateway_disabled();
            }

            return $result;
        }

        /**
         * Revalidate on settings save without hammering the remote API.
         *
         * @param array $license_data Current license data.
         *
         * @return void
         */
        protected function maybe_revalidate_license_after_settings_save($license_data)
        {
            $stored = $this->license_manager->get_license_data();

            if (empty($stored['license_key']) || empty($stored['email'])) {
                if ('active' === $stored['activation_status']) {
                    $this->license_manager->queue_notice(__('Please activate your FlujiPay license before using this plugin.', 'strowallet-woo-payment-gateway'), 'warning');
                }

                return;
            }

            if ('active' === $stored['activation_status']) {
                $this->license_manager->maybe_revalidate_stored_license('settings_save', true);

                return;
            }

            if (!$this->license_manager->is_license_active()) {
                $this->license_manager->queue_notice(__('Please activate your FlujiPay license before using this plugin.', 'strowallet-woo-payment-gateway'), 'warning');
            }
        }

        /**
         * Force the WooCommerce gateway setting to disabled when the license is invalid.
         *
         * @return void
         */
        protected function force_gateway_disabled()
        {
            $settings            = get_option('woocommerce_' . $this->id . '_settings', array());
            $settings['enabled'] = 'no';
            update_option('woocommerce_' . $this->id . '_settings', $settings, false);
            $this->enabled = 'no';
        }

        /**
         * Payment form on checkout page
         */
        public function payment_fields()
        {

            if ($this->description) {
                echo sanitize_text_field($this->description);
            }

            if (!is_ssl()) {
                return;
            }

            if ($this->supports('tokenization') && is_checkout() && $this->saved_cards && is_user_logged_in()) {
                $this->tokenization_script();
                $this->saved_payment_methods();
                $this->save_payment_method_checkbox();
            }
        }


        /**
         * Display strowallet payment icon.
         */
        public function get_icon()
        {

            $icon = '<img src="' . WC_HTTPS::force_https_url(plugins_url('assets/images/strowallet.png', WC_STROWALLET_MAIN_FILE)) . '" alt="FlujiPay Payment Options" style="height: 20px;" />';

            return apply_filters('woocommerce_gateway_icon', $icon, $this->id);
        }

        public function customURL()
        {
            if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
                $url = "https://";
            else
                $url = "http://";
            // Append the host(domain name, ip) to the URL.   
            $url .= $_SERVER['HTTP_HOST'];

            // Append the requested resource location to the URL   
            $url .= $_SERVER['REQUEST_URI'];

            //clean url
            $url = sanitize_url($url);

            return $url;
        }

        /**
         * Displays the payment page.
         *
         * @param $order_id
         */
        public function receipt_page($order_id)
        {
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }

            if (!isset($_SESSION['strowallet-woo-payment-gateway-session'])) {
                $_SESSION['strowallet-woo-payment-gateway-session'] = wp_generate_password(16, false, false);
            }

            if (isset($_GET['success'])) {
                $this->strowallet_verify_payment($order_id);
            }

            $order = wc_get_order($order_id);
            if (!$order) {
                wc_add_notice(__('Unable to initialize payment. Please try again.', 'strowallet-woo-payment-gateway'), 'error');
                return;
            }

            $order_total = method_exists($order, 'get_total') ? $order->get_total() : $order->order_total;
            $order_currency = method_exists($order, 'get_currency') ? $order->get_currency() : $order->order_currency;
            $session_ref = sanitize_text_field($_SESSION['strowallet-woo-payment-gateway-session']);
            $callback_base = $this->customURL();

            echo '<style>
                html, body { background:#ffffff !important; margin:0 !important; padding:0 !important; min-height:100vh !important; }
                body > * { display:none !important; }
                #flujipay-redirect-screen { display:flex !important; align-items:center; justify-content:center; min-height:100vh; width:100%; font-family:Arial, sans-serif; color:#1f2937; }
                #flujipay-redirect-box { text-align:center; }
                #flujipay-loader { width:46px; height:46px; border:4px solid #e5e7eb; border-top-color:#4f46e5; border-radius:9999px; margin:0 auto 14px; animation:flujipay-spin .9s linear infinite; }
                #flujipay-redirect-text { font-size:15px; color:#6b7280; }
                @keyframes flujipay-spin { to { transform: rotate(360deg); } }
            </style>';

            echo '<div id="flujipay-redirect-screen"><div id="flujipay-redirect-box"><div id="flujipay-loader"></div><div id="flujipay-redirect-text">' . esc_html__('Redirecting to secure payment...', 'strowallet-woo-payment-gateway') . '</div></div></div>';

            echo '<form id="strowallet-auto-redirect-form" method="post" action="' . esc_url($this->apiURL) . '" style="display:none !important;">'
                . '<input type="hidden" name="identifier" value="' . esc_attr($order_id) . '">'
                . '<input type="hidden" name="order_id" value="' . esc_attr($order_id) . '">'
                . '<input type="hidden" name="amount" value="' . esc_attr($order_total) . '">'
                . '<input type="hidden" name="currency" value="' . esc_attr($order_currency) . '">'
                . '<input type="hidden" name="details" value="' . esc_attr($order_id) . '">'
                . '<input type="hidden" name="public_key" value="' . esc_attr($this->public_key) . '">'
                . '<input type="hidden" name="site_name" value="' . esc_attr(get_bloginfo('name')) . '">'
                . '<input type="hidden" name="customer[first_name]" value="' . esc_attr($order->get_billing_first_name()) . '">'
                . '<input type="hidden" name="customer[last_name]" value="' . esc_attr($order->get_billing_last_name()) . '">'
                . '<input type="hidden" name="customer[email]" value="' . esc_attr($order->get_billing_email()) . '">'
                . '<input type="hidden" name="customer[mobile]" value="' . esc_attr($order->get_billing_phone()) . '">'
                . '<input type="hidden" name="shipping_info[address_one]" value="' . esc_attr($order->get_billing_address_1()) . '">'
                . '<input type="hidden" name="shipping_info[address_two]" value="' . esc_attr($order->get_billing_address_2()) . '">'
                . '<input type="hidden" name="shipping_info[city]" value="' . esc_attr($order->get_billing_city()) . '">'
                . '<input type="hidden" name="ipn_url" value="' . esc_url($callback_base) . '">'
                . '<input type="hidden" name="success_url" value="' . esc_url($callback_base . '&success=' . rawurlencode($session_ref)) . '">'
                . '<input type="hidden" name="cancel_url" value="' . esc_url($callback_base . '&cancel=' . rawurlencode($session_ref)) . '">'
                . '</form>';

            echo '<script>(function(){var f=document.getElementById("strowallet-auto-redirect-form");if(f){f.submit();}})();</script>';
            exit;
        }

        /**
         * Verify sknmart.
         */
        public function strowallet_verify_payment($order_id)
        {

            //If transactions_refrence is not set
            if (isset($_GET["success"]) && $_GET["success"] != "undefined" && $_GET["success"] != "") {
                //DO More
                $order = wc_get_order($order_id);
                $transactions_refrence = sanitize_text_field($_GET["success"]);
                if ($transactions_refrence == $_SESSION['strowallet-woo-payment-gateway-session']) {
                    //CLear Order
                    $order->payment_complete($transactions_refrence);
                    $order->update_status('completed');
                    $order->add_order_note('Payment was successful on FlujiPay');
                    $order->add_order_note(sprintf(__('Payment via FlujiPay successful (Transaction Reference: %s)', 'strowallet-woo-payment-gateway'), $transactions_refrence));
                    //Customer Note
                    $customer_note  = 'Thank you for your order.<br>';
                    $customer_note .= 'Your payment was successful, we are now <strong>processing</strong> your order.';

                    $order->add_order_note($customer_note, 1);

                    wc_add_notice($customer_note, 'notice');
                    //CLear Cart
                    WC()->cart->empty_cart();
                    //Quit and redirect
                    unset($_SESSION['strowallet-woo-payment-gateway-session']);
                    $redirect_url = trim($this->redirect_url);
                    if (!empty($redirect_url)) {
                        $redirect_url = esc_url_raw($redirect_url);
                    }
                    if (empty($redirect_url)) {
                        $redirect_url = $this->get_return_url($order);
                    }
                    wp_redirect($redirect_url);
                    exit;
                } else {
                    //If error
                    $order->update_status('Failed');

                    update_post_meta($order_id, '_transaction_id', $transactions_refrence);

                    $notice      = sprintf(__('Thank you for shopping with us.%1$sYour payment is currently having issues with verification and .%1$sYour order is currently on-hold.%2$sKindly contact us for more information regarding your order and payment status.', 'strowallet-woo-payment-gateway'), '<br />', '<br />');
                    $notice_type = 'notice';

                    // Add Customer Order Note
                    $order->add_order_note($notice, 1);

                    // Add Admin Order Note
                    $admin_order_note = sprintf(__('<strong>Look into this order</strong>%1$sThis order is currently on hold.%2$sReason: Payment can not be verified.%3$swhile the <strong>FlujiPay Transaction Reference:</strong> %4$s', 'strowallet-woo-payment-gateway'), '<br />', '<br />', '<br />', $transactions_refrence);
                    $order->add_order_note($admin_order_note);

                    function_exists('wc_reduce_stock_levels') ? wc_reduce_stock_levels($order_id) : $order->reduce_order_stock();

                    wc_add_notice($notice, $notice_type);
                }
            }

            wp_redirect(wc_get_page_permalink('cart'));

            exit;
        }

        /**
         * Process the payment.
         *
         * @param int $order_id
         *
         * @return array|void
         */
        public function process_payment($order_id)
        {
            if (!$this->license_manager->is_license_active()) {
                wc_add_notice(
                    __('Please activate your FlujiPay license before using this plugin.', 'strowallet-woo-payment-gateway'),
                    'error'
                );

                return array(
                    'result' => 'failure',
                );
            }

            if (is_user_logged_in() && isset($_POST['wc-' . $this->id . '-new-payment-method']) && true === (bool)
            $_POST['wc-' . $this->id . '-new-payment-method'] && $this->saved_cards) {

                update_post_meta($order_id, '_wc_strowallet_save_card', true);
            }

            $order = wc_get_order($order_id);
            $order_currency = method_exists($order, 'get_currency') ? $order->get_currency() : $order->order_currency;

            if (!$this->is_currency_supported($order_currency)) {
                wc_add_notice(
                    sprintf(
                        __('FlujiPay does not support %s for this checkout.', 'strowallet-woo-payment-gateway'),
                        esc_html($order_currency)
                    ),
                    'error'
                );

                return array(
                    'result' => 'failure',
                );
            }

            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true),
            );
        }

        /**
         * Check if this gateway is enabled and available in the user's country.
         */
        public function is_valid_for_use()
        {
            if (!$this->license_manager->is_license_active()) {
                $this->msg = __('Please activate your FlujiPay license before using this plugin.', 'strowallet-woo-payment-gateway');

                return false;
            }

            $supported_currencies = $this->get_enabled_supported_currencies();
            $current_currency     = get_woocommerce_currency();

            if (!in_array($current_currency, $supported_currencies, true)) {
                $supported_currency_list = implode(', ', $supported_currencies);

                $this->msg = sprintf(
                    __("FlujiPay does not support your store currency (%1\$s). Supported currencies are: %2\$s. Update it <a href='%3\$s'>here</a>.", 'strowallet-woo-payment-gateway'),
                    $current_currency,
                    $supported_currency_list,
                    admin_url('admin.php?page=wc-settings&tab=general')
                );

                return false;
            }

            return true;
        }

        /**
         * Load admin scripts.
         */
        public function admin_scripts()
        {

            if ('woocommerce_page_wc-settings' !== get_current_screen()->id) {
                return;
            }

            $suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '';

            $strowallet_admin_params = array(
                'plugin_url' => WC_STROWALLET_URL,
            );

            wp_enqueue_style('wc_strowallet_admin', plugins_url('assets/css/strowallet-admin.css', WC_STROWALLET_MAIN_FILE), array(), WC_STROWALLET_VERSION);
            wp_enqueue_script('wc_strowallet_admin', plugins_url('assets/js/strowallet-admin' . $suffix . '.js', WC_STROWALLET_MAIN_FILE), array(), WC_STROWALLET_VERSION, true);

            wp_localize_script('wc_strowallet_admin', 'wc_strowallet_admin_params', $strowallet_admin_params);
        }

        /**
         * Outputs scripts used for strowallet payment.
         */
        public function payment_scripts()
        {

            if (!is_checkout_pay_page()) {
                return;
            }

            if ($this->enabled === 'no') {
                return;
            }

            if (!$this->license_manager->is_license_active()) {
                return;
            }

            $order_key = sanitize_text_field(urldecode($_GET['key']));
            $order_id  = absint(get_query_var('order-pay'));

            $order = wc_get_order($order_id);
            $api_verify_url = WC()->api_request_url('WC_strowallet_Payment_Gateway') . '?strowallet_id=' . $order_id;

            $payment_method = method_exists($order, 'get_payment_method') ? $order->get_payment_method() : $order->payment_method;

            if ($this->id !== $payment_method) {
                return;
            }

            if (is_checkout_pay_page() && get_query_var('order-pay')) {

                $email         = method_exists($order, 'get_billing_email') ? $order->get_billing_email() : $order->billing_email;
                $amount        = $order->get_total();
                $txnref        = $order_id . '_' . time();
                $the_order_id  = method_exists($order, 'get_id') ? $order->get_id() : $order->id;
                $the_order_key = method_exists($order, 'get_order_key') ? $order->get_order_key() : $order->order_key;
                $currency      = method_exists($order, 'get_currency') ? $order->get_currency() : $order->order_currency;

                if ($the_order_id == $order_id && $the_order_key == $order_key) {

                    // $strowallet_params['email']        = $email;
                    // $strowallet_params['amount']       = $amount;
                    // $strowallet_params['txnref']       = $txnref;
                    // $strowallet_params['pay_page']     = $this->payment_page;
                    // $strowallet_params['currency']     = $currency;
                    // $strowallet_params['bank_channel'] = 'true';
                    // $strowallet_params['card_channel'] = 'true';
                    // $strowallet_params['first_name'] = $order->get_billing_first_name();
                    // $strowallet_params['last_name'] = $order->get_billing_last_name();
                    // $strowallet_params['phone'] = $order->get_billing_phone();
                    // $strowallet_params['card_channel'] = 'true';

                }
                update_post_meta($order_id, '_strowallet_txn_ref', $txnref);
            }
        }

        /**
         * Check if strowallet merchant details is filled.
         */
        public function admin_notices()
        {
            if (!current_user_can('manage_woocommerce')) {
                return;
            }

            // Check required fields.
            if (!($this->public_key && $this->secret_key)) {
                $mode_label = $this->testmode ? __('test', 'strowallet-woo-payment-gateway') : __('live', 'strowallet-woo-payment-gateway');
                echo '<div class="error"><p>' . sprintf(__('Please enter your FlujiPay %1$s keys <a href="%2$s">here</a> to be able to use the FlujiPay WooCommerce plugin.', 'strowallet-woo-payment-gateway'), $mode_label, admin_url('admin.php?page=wc-settings&tab=checkout&section=strowallet')) . '</p></div>';
                return;
            }

            if (!$this->license_manager->is_license_active()) {
                echo '<div class="notice notice-error"><p>' . esc_html__('Please activate your FlujiPay license before using this plugin.', 'strowallet-woo-payment-gateway') . '</p></div>';
            }
        }

        /**
         * Check if strowallet gateway is enabled.
         *
         * @return bool
         */
        public function is_available()
        {
            if ('yes' == $this->enabled) {
                if (!$this->license_manager->is_license_active()) {
                    return false;
                }

                if (!($this->public_key && $this->secret_key)) {

                    return false;
                }

                return true;
            }

            return false;
        }

        /**
         * Add Gateway to checkout page.
         *
         * @param $available_gateways
         *
         * @return mixed
         */
        public function add_gateway_to_checkout($available_gateways)
        {
            if ('no' == $this->enabled || !$this->license_manager->is_license_active()) {
                unset($available_gateways[$this->id]);
            }

            return $available_gateways;
        }
    }
}
